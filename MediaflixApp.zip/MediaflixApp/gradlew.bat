@rem Gradle startup script for Windows
@echo off
setlocal

set DIRNAME=%~dp0
set APP_HOME=%DIRNAME%

set JAVA_EXE=java.exe
set GRADLE_OPTS=-Xmx2048m

"%JAVA_EXE%" %GRADLE_OPTS% -classpath "%APP_HOME%\gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
