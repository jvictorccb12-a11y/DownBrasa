#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  Script de Build — MediaflixApp
#  Gera o AAB assinado pronto para a Play Store
# ═══════════════════════════════════════════════════════════════

set -e  # Para imediatamente em caso de erro

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo ""
echo "╔══════════════════════════════════════╗"
echo "║    Mediaflix — Build para Play Store  ║"
echo "╚══════════════════════════════════════╝"
echo ""

# ── 1. Verificar pré-requisitos ────────────────────────────────
echo -e "${YELLOW}[1/4] Verificando pré-requisitos...${NC}"

if ! command -v java &> /dev/null; then
    echo -e "${RED}ERRO: Java não encontrado. Instale o JDK 17 ou 21.${NC}"
    echo "      Download: https://adoptium.net/"
    exit 1
fi

JAVA_VER=$(java -version 2>&1 | head -1)
echo "      Java: $JAVA_VER"

if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
    # Tentar localizar o SDK automaticamente
    COMMON_SDK_PATHS=(
        "$HOME/Library/Android/sdk"                           # macOS
        "$HOME/Android/Sdk"                                   # Linux
        "$LOCALAPPDATA/Android/Sdk"                           # Windows (WSL)
        "/usr/lib/android-sdk"
    )
    for p in "${COMMON_SDK_PATHS[@]}"; do
        if [ -d "$p" ]; then
            export ANDROID_HOME="$p"
            echo "      Android SDK localizado: $ANDROID_HOME"
            break
        fi
    done

    if [ -z "$ANDROID_HOME" ]; then
        echo -e "${RED}ERRO: ANDROID_HOME não definido e SDK não encontrado.${NC}"
        echo "      Instale o Android Studio: https://developer.android.com/studio"
        echo "      Depois defina: export ANDROID_HOME=~/Android/Sdk"
        exit 1
    fi
fi

echo "      Android SDK: $ANDROID_HOME"

# ── 2. Gerar keystore (só na primeira vez) ─────────────────────
echo ""
echo -e "${YELLOW}[2/4] Verificando keystore...${NC}"

KEYSTORE="app/mediaflix-release.keystore"

if [ ! -f "$KEYSTORE" ]; then
    echo "      Keystore não encontrado. Gerando..."
    echo ""
    read -p "      Senha do keystore (mínimo 6 chars): " -s KS_PASS
    echo ""
    
    keytool -genkeypair \
        -v \
        -storetype PKCS12 \
        -keyalg RSA \
        -keysize 2048 \
        -validity 10000 \
        -storepass "$KS_PASS" \
        -keypass "$KS_PASS" \
        -alias mediaflix-key \
        -keystore "$KEYSTORE" \
        -dname "CN=Mediaflix, OU=Dev, O=Mediaflix, L=Sao Paulo, S=SP, C=BR"

    # Atualizar gradle.properties com a senha
    sed -i "s/MYAPP_STORE_PASSWORD=.*/MYAPP_STORE_PASSWORD=$KS_PASS/" gradle.properties
    sed -i "s/MYAPP_KEY_PASSWORD=.*/MYAPP_KEY_PASSWORD=$KS_PASS/" gradle.properties

    echo -e "${GREEN}      Keystore gerado: $KEYSTORE${NC}"
    echo -e "${YELLOW}      ⚠  IMPORTANTE: Faça backup deste arquivo! Sem ele não dá para atualizar o app.${NC}"
else
    echo -e "${GREEN}      Keystore encontrado: $KEYSTORE${NC}"
fi

# ── 3. Limpar build anterior ───────────────────────────────────
echo ""
echo -e "${YELLOW}[3/4] Limpando build anterior...${NC}"
./gradlew clean --quiet

# ── 4. Gerar AAB de release ────────────────────────────────────
echo ""
echo -e "${YELLOW}[4/4] Gerando bundle AAB (pode demorar 2-5 minutos na primeira vez)...${NC}"
./gradlew bundleRelease

AAB_PATH="app/build/outputs/bundle/release/app-release.aab"

if [ -f "$AAB_PATH" ]; then
    SIZE=$(du -sh "$AAB_PATH" | cut -f1)
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║  ✅  BUILD CONCLUÍDO COM SUCESSO!             ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════════════╝${NC}"
    echo ""
    echo "  Arquivo:  $AAB_PATH"
    echo "  Tamanho:  $SIZE"
    echo ""
    echo "  Próximo passo:"
    echo "  → Acesse https://play.google.com/console"
    echo "  → Crie um novo app → faça upload do .aab"
    echo ""
else
    echo -e "${RED}ERRO: AAB não foi gerado. Verifique os erros acima.${NC}"
    exit 1
fi
