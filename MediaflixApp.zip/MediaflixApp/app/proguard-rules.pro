# WebView JavaScript interface
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Manter nomes de classes para o FileProvider
-keep class androidx.core.content.FileProvider

# Kotlin
-keep class kotlin.** { *; }
-dontwarn kotlin.**
