package com.mediaflixapp

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.webkit.*
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.mediaflixapp.databinding.ActivityMainBinding
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var downloadId: Long = -1L

    // ── BroadcastReceiver: escuta quando o download termina ────────────────
    private val downloadReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
            if (id == downloadId) {
                val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
                val query = DownloadManager.Query().setFilterById(id)
                val cursor = dm.query(query)
                if (cursor.moveToFirst()) {
                    val statusIdx  = cursor.getColumnIndex(DownloadManager.COLUMN_STATUS)
                    val localIdx   = cursor.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)
                    if (statusIdx >= 0 && cursor.getInt(statusIdx) == DownloadManager.STATUS_SUCCESSFUL) {
                        val localUri = if (localIdx >= 0) cursor.getString(localIdx) else null
                        if (localUri != null) installApk(Uri.parse(localUri))
                    }
                }
                cursor.close()
            }
        }
    }

    // ── Resultado da permissão de armazenamento ────────────────────────────
    private val storagePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) {
                Toast.makeText(this, "Permissão de armazenamento necessária para baixar arquivos.", Toast.LENGTH_LONG).show()
            }
        }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ── Registrar receiver de download ────────────────────────────────
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(downloadReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(downloadReceiver, filter)
        }

        setupWebView()
        setupSwipeRefresh()
        loadPage()
    }

    // ── Configuração do WebView ────────────────────────────────────────────
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        with(binding.webView.settings) {
            javaScriptEnabled        = true
            domStorageEnabled        = true
            databaseEnabled          = true
            allowFileAccess          = true
            loadWithOverviewMode     = true
            useWideViewPort          = true
            builtInZoomControls      = false
            displayZoomControls      = false
            setSupportZoom(false)
            mixedContentMode         = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode                = WebSettings.LOAD_DEFAULT
            userAgentString          = userAgentString.replace("; wv", "") // oculta que é WebView
        }

        // ── WebViewClient: navegação e erros ──────────────────────────────
        binding.webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url.toString()
                return when {
                    // APK → download nativo
                    url.endsWith(".apk", ignoreCase = true) ||
                    url.contains(".apk?", ignoreCase = true) -> {
                        startApkDownload(url)
                        true
                    }
                    // Schemas externos → abrir app externo
                    url.startsWith("whatsapp://") ||
                    url.startsWith("tg://")       ||
                    url.startsWith("intent://")   -> {
                        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {}
                        true
                    }
                    else -> false
                }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: android.graphics.Bitmap?) {
                binding.progressBar.visibility = View.VISIBLE
                binding.layoutOffline.visibility = View.GONE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                binding.progressBar.visibility     = View.GONE
                binding.swipeRefresh.isRefreshing  = false
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    binding.progressBar.visibility  = View.GONE
                    if (!isOnline()) {
                        binding.layoutOffline.visibility = View.VISIBLE
                    }
                }
            }
        }

        // ── WebChromeClient: título, progresso ────────────────────────────
        binding.webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                binding.progressBar.progress = newProgress
                if (newProgress == 100) binding.progressBar.visibility = View.GONE
            }
        }

        // ── Interceptar download via DownloadListener ─────────────────────
        binding.webView.setDownloadListener { url, _, _, mimetype, _ ->
            if (mimetype == "application/vnd.android.package-archive" ||
                url.endsWith(".apk", ignoreCase = true)) {
                startApkDownload(url)
            }
        }
    }

    // ── Swipe para recarregar ──────────────────────────────────────────────
    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setColorSchemeResources(R.color.colorPrimary)
        binding.swipeRefresh.setOnRefreshListener {
            if (isOnline()) binding.webView.reload()
            else {
                binding.swipeRefresh.isRefreshing = false
                Toast.makeText(this, "Sem conexão com a internet", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ── Carregar a página ──────────────────────────────────────────────────
    private fun loadPage() {
        if (isOnline()) {
            binding.layoutOffline.visibility = View.GONE
            binding.webView.loadUrl(STORE_URL)
        } else {
            binding.progressBar.visibility   = View.GONE
            binding.layoutOffline.visibility = View.VISIBLE
        }
        binding.btnRetry.setOnClickListener { loadPage() }
    }

    // ── Download de APK via DownloadManager ───────────────────────────────
    private fun startApkDownload(url: String) {
        // Android < 10: solicitar permissão de escrita
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
                storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                return
            }
        }

        Toast.makeText(this, "⬇ Baixando... aguarde", Toast.LENGTH_SHORT).show()

        val fileName = url.substringAfterLast("/").substringBefore("?").ifEmpty { "app.apk" }

        val request = DownloadManager.Request(Uri.parse(url)).apply {
            setTitle(fileName)
            setDescription("Baixando $fileName")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            addRequestHeader("User-Agent", binding.webView.settings.userAgentString)
        }

        val dm = getSystemService(DOWNLOAD_SERVICE) as DownloadManager
        downloadId = dm.enqueue(request)
    }

    // ── Instalar APK baixado ───────────────────────────────────────────────
    private fun installApk(fileUri: Uri) {
        // Android 8+: verificar se pode instalar apps desconhecidos
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !packageManager.canRequestPackageInstalls()) {
            AlertDialog.Builder(this)
                .setTitle("Permissão necessária")
                .setMessage("Para instalar o app, habilite "Instalar apps desconhecidos" para o ${getString(R.string.app_name)} nas configurações.")
                .setPositiveButton("Abrir configurações") { _, _ ->
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                               Uri.parse("package:$packageName"))
                    )
                }
                .setNegativeButton("Cancelar", null)
                .show()
            return
        }

        val path = fileUri.path ?: return
        val file = File(path)
        if (!file.exists()) {
            Toast.makeText(this, "Arquivo não encontrado", Toast.LENGTH_SHORT).show()
            return
        }

        val apkUri = FileProvider.getUriForFile(this, "$packageName.provider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(apkUri, "application/vnd.android.package-archive")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
        }
        startActivity(intent)
    }

    // ── Verificar conexão ──────────────────────────────────────────────────
    private fun isOnline(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(net) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    // ── Botão voltar físico ────────────────────────────────────────────────
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (binding.webView.canGoBack()) {
            binding.webView.goBack()
        } else {
            super.onBackPressed()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(downloadReceiver)
    }

    companion object {
        const val STORE_URL = "https://mediaflix.com.br/loja/"
    }
}
