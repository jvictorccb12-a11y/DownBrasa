# Mediaflix App — Android WebView

App Android nativo (Kotlin) para a loja Mediaflix.  
Funciona como WebView de `https://mediaflix.com.br/loja/` com suporte a download e instalação de APKs.

---

## ✅ Funcionalidades

- WebView carregando a loja com swipe para recarregar
- Intercepta links `.apk` → usa DownloadManager nativo
- FileProvider configurado para instalar APKs (Android 7+)
- Solicita permissão `REQUEST_INSTALL_PACKAGES` (Android 8+)
- Tela offline com botão "Tentar novamente"
- Botão voltar físico navega no histórico da WebView
- Barra de progresso de carregamento
- targetSdkVersion 34 (compatível com Play Store 2025)

---

## 🚀 Build rápido (Linux / macOS)

### Pré-requisitos
- JDK 17 ou 21: https://adoptium.net/
- Android Studio: https://developer.android.com/studio

### Rodar o script automático
```bash
chmod +x build.sh
./build.sh
```

O script vai:
1. Verificar os pré-requisitos
2. Gerar o keystore automaticamente (se não existir)
3. Limpar e buildar
4. Mostrar o caminho do `.aab` gerado

---

## 🪟 Build no Windows

```bat
gradlew.bat bundleRelease
```

Ou abra o projeto no **Android Studio** → menu Build → Generate Signed Bundle.

---

## 📦 Saída do build

```
app/build/outputs/bundle/release/app-release.aab
```

Faça upload deste arquivo na Google Play Console.

---

## 🔑 Keystore (IMPORTANTE)

O arquivo `app/mediaflix-release.keystore` é gerado automaticamente pelo `build.sh`.

**⚠ Faça backup!** Sem ele é impossível publicar atualizações do app na Play Store.

---

## 🎨 Personalizar o app

| O que mudar | Onde |
|---|---|
| URL da loja | `MainActivity.kt` → constante `STORE_URL` |
| Nome do app | `res/values/strings.xml` |
| Cor primária | `res/values/colors.xml` → `colorPrimary` |
| Ícone | Substituir os arquivos `ic_launcher.png` em cada pasta `mipmap-*` |
| Package ID | `app/build.gradle` → `applicationId` + `AndroidManifest.xml` → `authorities` |
| Versão | `app/build.gradle` → `versionCode` e `versionName` |

---

## 📋 Checklist Play Store

- [ ] Ícone 512x512 PNG (sem transparência) — para a ficha do app
- [ ] Feature graphic 1024x500 PNG
- [ ] Pelo menos 2 screenshots
- [ ] Política de privacidade (URL obrigatória)
- [ ] Preencher declaração de `REQUEST_INSTALL_PACKAGES` na Play Console
- [ ] Classificação de conteúdo (questionário na Play Console)

---

## 🏗 Estrutura do projeto

```
MediaflixApp/
├── app/
│   ├── build.gradle                     ← Versão, SDK, signing
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml          ← Permissões, FileProvider
│       ├── java/com/mediaflixapp/
│       │   ├── MainActivity.kt          ← WebView principal
│       │   └── MainApplication.kt
│       └── res/
│           ├── layout/activity_main.xml
│           ├── values/ (colors, strings, themes)
│           └── xml/ (file_paths, network_security_config)
├── gradle/wrapper/
├── build.gradle
├── settings.gradle
├── gradle.properties                    ← Senhas do keystore
├── gradlew  /  gradlew.bat
├── build.sh                             ← Script de build automático
└── README.md
```
